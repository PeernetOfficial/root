exports.Settings = {
  webpack: {
    rules: [
      {
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              [
                '@babel/preset-env',
                {
                  targets: {
                    ie: '11'
                  }
                }
              ]
            ]
          }
        }
      }
    ],
    target: 'web'
  },
  path: {
    src: './production',
    dest: './dist'
  }
};
