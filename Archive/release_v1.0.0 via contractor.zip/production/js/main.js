import Chart from 'chart.js/auto';
import axios from 'axios';

// Remove for production
// const DATA = JSON.parse('{"today":{"date":"2021-06-25T17:39:57.8526255Z","active":6,"root":4,"nat":0,"portforward":0},"daily":[{"date":"2021-06-11T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-12T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-13T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-14T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-15T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-16T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-17T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-18T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-19T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-20T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-21T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-22T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-23T00:00:00Z","active":8,"root":4,"nat":0,"portforward":1},{"date":"2021-06-24T00:00:00Z","active":7,"root":4,"nat":0,"portforward":0},{"date":"2021-06-25T00:00:00Z","active":6,"root":4,"nat":0,"portforward":0}]}');

let DATA = {};

const COLOR = {
  primary: '75, 192, 192',
  alt: '142, 68, 173',
  ter: '44, 62, 80'
};

const URL = document.querySelector('.js-root').getAttribute('data-url-api');

axios({
  method: 'GET',
  url: URL,
  responseType: 'json',
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json;charset=UTF-8',
  },
})
  .then(function (response) {
    // handle success
    DATA = {...response.data};

    onReady();
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })
  .then(function () {
    // always executed
  });

const onReady = () => {
  const renderActive = () => {
    const active = document.querySelector('.js-active');
    const activeTotal = active.querySelector('.js-active__total');

    activeTotal.textContent = DATA.today.active;
  };

  renderActive();

  const charts = {
    target: {
      daily: document.querySelector('.js-chart-daily'),
      kpi: document.querySelector('.js-chart-kpi')
    },
    loaders: document.querySelectorAll('.js-chart-loader')
  };

  const getDates = () => {
    return DATA.daily.map(item => {
      const date = new Date(item.date);

      return `${date.getDate()}.${date.getMonth()}.${date.getFullYear()}`;
    });
  };

  const getActives = () => {
    return DATA.daily.map(item => item.active);
  };

  const createGradient = color => {
    const gradient = charts.target.daily.getContext("2d").createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, `rgba(${color},1)`);
    gradient.addColorStop(1, `rgba(${color},0)`);

    return gradient;
  };

  const lineChart = new Chart(charts.target.daily, {
    type: 'line',
    data: {
      labels: getDates(),
      datasets: [
        {
          label: 'Daily',
          data: getActives(),
          fill: false,
          borderColor: `rgb(${COLOR.primary})`,
          tension: 0.1,
          // backgroundColor: createGradient(COLOR.primary),
          // fill: true,
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        legend: false
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 1
          },
        }
      }
    }
  });

  const lineChartKpi = new Chart(charts.target.kpi, {
    type: 'line',
    data: {
      labels: getDates(),
      datasets: [
        {
          label: 'Root',
          data: DATA.daily.map(item => item.root),
          fill: false,
          borderColor: `rgb(${COLOR.primary})`,
          tension: 0.1,
        },
        {
          label: 'NAT',
          data: DATA.daily.map(item => item.nat),
          fill: false,
          borderColor: `rgb(${COLOR.alt})`,
          tension: 0.1,
        },
        {
          label: 'Port Forward',
          data: DATA.daily.map(item => item.portforward),
          fill: false,
          borderColor: `rgb(${COLOR.ter})`,
          tension: 0.1,
        },
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          // beginAtZero: true
          ticks: {
            stepSize: 1
          },
        }
      }
    }
  });

  charts.loaders.forEach(loader => {
    loader.classList.add('is-loaded')
  });
};
